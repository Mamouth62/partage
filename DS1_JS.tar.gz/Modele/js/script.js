document.addEventListener("DOMContentLoaded", () => {
    let nb;
    const btBleu = document.querySelector("btBleu");
    const btRouge = document.querySelector("btRouge");
    bleu.addEventListener("click", bleuClick, false);
    rouge.removeEventListener("click", rougeClick, false);




    const cpt = document.querySelector("#cpt1");
    cpt.textContent = nb;
    const cpt = document.querySelector("#cpt2");
    cpt.textContent = nb;



    function btBleu() {



    }

});